public class TesteVariaveis {
    public static void main(String[] args){
        int a = 11, b = 4;
        System.out.printf("soma = %d\n", a+b);
        System.out.print("multiplicacao = " + a*b);
        System.out.println("\nsubtracao = " + (a-b));
        System.out.println("divisão = " + a/b);
        System.out.println("concatenacao = " + a + b);
    }
}
