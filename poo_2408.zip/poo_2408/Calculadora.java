//ler 2 numeros e uma operacao (+, -, *, /), executá-la e mostrar o resultado
import java.util.Scanner;
public class Calculadora{
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        double n1, n2, resultado;

        System.out.print("Digite um numero: ");
        n1 = scanner.nextDouble();
        System.out.println("Digite outro numero: ");
        n2 = scanner.nextDouble();

        System.out.println("Escolha a forma de calcular:\n(+) Soma\n(-) Subtracao\n(*)Multiplicacao\n(/)Divisao\n");
        scanner.nextLine();
        char operacao = scanner.nextLine().charAt(0);

        if(operacao == '+'){
            resultado = n1+n2;
            System.out.println("A soma é: " + resultado);
        }else if(operacao == '-'){
            resultado = n1-n2;
            System.out.println("A subtracao é: " + resultado);
        }else if(operacao == '*'){
            resultado = n1*n2;
            System.out.println("A multiplicacao é: " + resultado);
        }else if(operacao == '/'){
            if(n2 == 0){
                System.out.println("Nao existe divisao por 0");
            }else{
                resultado = n1/n2;
                System.out.println("A divisao é: " + resultado);
            }
        }else{
            System.out.println("Escolha incorreta");
        }

        scanner.close();
    }
}