import java.util.Scanner;
public class SegundoGrau {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        double a, b, c, delta, raiz, x1, x2;

        System.out.println("Digite o valor de A: ");
        a = scanner.nextDouble();
        System.out.println("Digite o valor de B: ");
        b = scanner.nextDouble();
        System.out.println("Digite o valor de C: ");
        c = scanner.nextDouble();

        if(a == 0){
            System.out.println("Não é de segundo grau");
        }else{
            delta = (b*b)-4*a*c;
            if(delta < 0){
                System.out.println("Não possui raiz real");
            }else{
                raiz = Math.sqrt(delta);
                x1 = ((-b - raiz)/(2*a));
                x2 = ((-b + raiz)/(2*a));

                System.out.println("Valor de x1 = " + x1 + "\nValor de x2 = " + x2);
            }
        }
        scanner.close();
    }
}
