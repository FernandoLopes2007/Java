import java.util.Scanner;
public class ManStrings {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        String palavra = scanner.nextLine();

        System.out.println("Tamanho da palavra: " + palavra.length());
        System.out.println("A primeira letra é " + palavra.charAt(0));
        System.out.println("A ultima letra é " + palavra.charAt(palavra.length()-1));

        scanner.close();
    }
}
