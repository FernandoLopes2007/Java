import java.util.Scanner;
public class TesteScanner {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        //iniciamos um "objeto Scanner" associado a entrada padrao System.in
        System.out.print("Digite um inteiro:\n-->");
        int inteiro = scanner.nextInt();
        System.out.print("Digite um dupla presisao:\n-->");
        double decimal = scanner.nextDouble();
        System.out.print("Digite um booleano: (true/false)\n-->");
        boolean eHexa = scanner.nextBoolean();

        //vamos usar um nextline() para descantar o enter anterior, depois realizar a leitura
        scanner.nextLine();
        // descante do enter
        System.out.print("Digite seu nome completo:\n-->");
        // String nome = scanner.next();
        // falha porque para no "espaco em branco"
        String nome = scanner.nextLine();
      
        
        System.out.println("Digite outro inteiro:\n-->");
        int outroInteiro = scanner.nextInt();

        System.out.println("\nConfira seus valores:");
        System.out.println("inteiro: " + inteiro);
        System.out.println("o decimal: " + decimal);
        System.out.println("o booleano: " + eHexa);
        System.out.println("seu nome: "+ nome);
        System.out.println("outro inteiro: "+ outroInteiro);
        scanner.close();
        //liberando o recurso associado ao scanner
    }
}
